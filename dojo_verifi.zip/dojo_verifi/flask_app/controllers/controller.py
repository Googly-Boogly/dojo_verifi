
from flask_app.models.dojo import Dojo
from flask import render_template,redirect,request,session,flash

from flask import Flask, render_template, request, redirect
from flask_app.templates import app

print('test')

@app.route("/")
def authors3():
    return render_template("index.html")

@app.route("/show")
def authors48():
    if not session['data']:
        redirect('/')
    data = session['data']
    return render_template("result.html", data=data)

@app.route("/create/dojo", methods=['POST'])
def authors26():
    data = {
        'name': request.form['name'],
        'language': request.form['language'],
        'comment': request.form['comment'],
        'location': request.form['location']
    }
    if not Dojo.validate(data):
        return redirect("/")
    print(Dojo.validate(data))
    Dojo.save(data)
    session['data'] = data
    return redirect("/show")