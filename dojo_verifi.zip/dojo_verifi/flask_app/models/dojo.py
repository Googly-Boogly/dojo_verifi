
from flask_app.config.mysqlconnection import connectToMySQL
from flask import render_template,redirect,request,session,flash
class Dojo:
    def __init__( self , data):
        self.name = data['name']
        self.location = data['location']
        self.language = data['language']
        self.comment = data['comment']
    @classmethod
    def save(cls, data ):
        query = "INSERT INTO dojos ( name, location, language, comment ) VALUES ( %(name)s,  %(location)s,  %(language)s,  %(comment)s);"
        return connectToMySQL('dojo_survey_schema').query_db( query, data )
    @staticmethod
    def validate(data):
        veri = True
        if len(data['name']) < 3:
            flash('name is not 3 character long')
            veri = False
        if len(data['location']) < 3:
            flash('location is not 3 character long')
            veri = False
        if len(data['language']) < 3:
            flash('language is not 3 character long')
            veri = False
        if len(data['comment']) < 3:
            flash('comment is not 3 character long')
            veri = False
        return veri